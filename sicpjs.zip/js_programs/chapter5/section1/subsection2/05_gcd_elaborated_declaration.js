const gcd_elaborated_controller =
