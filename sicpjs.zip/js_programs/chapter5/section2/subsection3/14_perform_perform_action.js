function perform(action) { return list("perform", action); }
function perform_action(inst) { return head(tail(inst)); }
