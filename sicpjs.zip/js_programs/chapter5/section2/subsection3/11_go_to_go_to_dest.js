function go_to(label) { return list("go_to", label); }
function go_to_dest(go_to_inst) { return head(tail(go_to_inst)); }
