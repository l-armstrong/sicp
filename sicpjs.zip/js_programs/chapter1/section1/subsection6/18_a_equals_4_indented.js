const a = 3;
const b = a + 1;
a === 4
? 6
: b === 4 
  ? 6 + 7 + a
  : 25;

// expected: 16
