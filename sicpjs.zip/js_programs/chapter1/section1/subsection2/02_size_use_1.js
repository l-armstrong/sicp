const size = 2;
size;

// expected: 2
