const pi = 3.14159;
const radius = 10;
const circumference = 2 * pi * radius;
circumference;

// expected: 62.8318
