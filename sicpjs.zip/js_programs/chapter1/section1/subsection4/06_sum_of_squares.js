function square(x) {
    return x * x;
}
function sum_of_squares(x,y) {
    return square(x) + square(y);
}

sum_of_squares(3, 4);

// expected: 25
