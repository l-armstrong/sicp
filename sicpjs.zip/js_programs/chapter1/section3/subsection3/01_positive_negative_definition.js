function positive(x) { return x > 0; }
function negative(x) { return x < 0; }
