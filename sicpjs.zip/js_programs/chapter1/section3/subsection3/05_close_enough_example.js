close_enough(7.7654, 7.7666);
