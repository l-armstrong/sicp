function inc(n) {
    return n + 1;
}
