first_answer('or(supervisor(x, list("Bitdiddle", "Ben")), supervisor(x, list("Hacker", "Alyssa", "P")))');

// expected: "or(supervisor(list('Tweakit', 'Lem', 'E'), list('Bitdiddle', 'Ben')), supervisor(list('Tweakit', 'Lem', 'E'), list('Hacker', 'Alyssa', 'P')))"
