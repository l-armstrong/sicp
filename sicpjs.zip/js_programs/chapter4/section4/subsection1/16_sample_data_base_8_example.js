first_answer('can_do_job(x, pair("computer", y))');

// expected: "can_do_job(list('computer', 'programmer'), list('computer', 'programmer', 'trainee'))"
