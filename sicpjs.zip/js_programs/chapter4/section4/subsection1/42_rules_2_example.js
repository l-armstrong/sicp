first_answer('wheel(who)');

// expected: "wheel(list('Warbucks', 'Oliver'))"
