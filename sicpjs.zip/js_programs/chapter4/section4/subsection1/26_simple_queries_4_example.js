first_answer('job($x, list("computer",  $type))');

// expected: "job(list('Tweakit', 'Lem', 'E'), list('computer', 'technician'))"
