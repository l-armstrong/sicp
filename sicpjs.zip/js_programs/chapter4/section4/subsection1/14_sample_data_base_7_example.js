first_answer('can_do_job(x, list("computer", y))');

// expected: "can_do_job(list('computer', 'wizard'), list('computer', 'technician'))"
