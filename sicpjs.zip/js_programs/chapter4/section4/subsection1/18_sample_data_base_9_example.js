first_answer('can_do_job(list(x, "assistant"), y)');

// expected: "can_do_job(list('administration', 'assistant'), list('administration', 'big', 'wheel'))"
