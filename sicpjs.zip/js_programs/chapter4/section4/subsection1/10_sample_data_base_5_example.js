first_answer('job(x, pair("accounting", y))');

// expected: "job(list('Cratchit', 'Robert'), list('accounting', 'scrivener'))"
