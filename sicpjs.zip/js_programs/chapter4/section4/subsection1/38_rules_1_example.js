first_answer('lives_near(list("Reasoner", "Louis"), who)');

// expected: "lives_near(list('Reasoner', 'Louis'), list('Aull', 'DeWitt'))"
