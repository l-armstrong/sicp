first_answer('and(supervisor(x, list("Bitdiddle", "Ben")), not(job(x, list("computer", "programmer"))))');

// expected: "and(supervisor(list('Tweakit', 'Lem', 'E'), list('Bitdiddle', 'Ben')), not(job(list('Tweakit', 'Lem', 'E'), list('computer', 'programmer'))))"
