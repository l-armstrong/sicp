first_answer('job($x, list("computer", "programmer"))');

// expected: "job(list('Fect', 'Cy', 'D'), list('computer', 'programmer'))"
