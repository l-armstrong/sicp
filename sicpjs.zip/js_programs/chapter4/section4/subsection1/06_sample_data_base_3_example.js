first_answer('supervisor(list("Reasoner", x), y)');

// expected: "supervisor(list('Reasoner', 'Louis'), list('Hacker', 'Alyssa', 'P'))"
