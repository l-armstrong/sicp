first_answer('supervisor(list("Reasoner", x), y)');
