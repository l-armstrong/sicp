first_answer('job(x, pair("computer", $type))');

// expected: "job(list('Reasoner', 'Louis'), list('computer', 'programmer', 'trainee'))"
