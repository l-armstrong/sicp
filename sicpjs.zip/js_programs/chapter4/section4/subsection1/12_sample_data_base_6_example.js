first_answer('address(x, list(y, list("Onion", "Square"), n))');

// expected: "address(list('Aull', 'DeWitt'), list('Slumerville', 'Onion Square', 5))"
