first_answer('and(salary($person, $amount), javascript_value($amount > 50000))');

// expected: "and(salary(list('Scrooge', 'Eben'), 141421), javascript_value((141421 > 50000)))"
