first_answer('address(x, list("Swellesley", y))');

// expected: "address(list('Warbucks', 'Oliver'), list('Swellesley', 'Top Heap Road'))"
