first_answer('supervisor(x, list("Bitdiddle", "Ben"))');

// expected: "supervisor(list('Tweakit', 'Lem', 'E'), list('Bitdiddle', 'Ben'))"
