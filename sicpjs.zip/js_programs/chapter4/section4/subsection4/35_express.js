function instantiate_datum(datum, frame) {
    if (is_variable(datum)) {
        const binding = binding_in_frame(datum, frame);
        return is_undefined(binding)
               ? datum
               : instantiate_datum(binding_value(binding), frame);
    } else if (is_pair(datum)) {
        return pair(instantiate_datum(head(datum), frame), 
                    instantiate_datum(tail(datum), frame));
    } else { // datum is a primitive value
        return datum;
    }
}
