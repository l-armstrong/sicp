const is_var = is_name;
const symbol_of_var = symbol_of_name;
