function make_new_variable(variable, rule_application_id) {
    return make_variable(pair(rule_application_id, symbol_of_name(variable)));
}
