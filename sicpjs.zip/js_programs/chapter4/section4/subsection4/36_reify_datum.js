function reify_datum(datum) {
    return is_variable(datum)
           ? datum
           : is_pair(datum)
           ? make_application(make_name("pair"),
                              list(reify_datum(head(datum)),
                                   reify_datum(tail(datum))))
           : // datum is a primitive value
             make_literal(datum);
}
