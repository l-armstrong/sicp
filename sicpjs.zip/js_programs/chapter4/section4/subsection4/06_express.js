function express_with_bindings(value, frame) {
    if (is_variable(value)) {
        const binding = binding_in_frame(value, frame);
        if (is_undefined(binding)) {
            return variable_to_name(value);
        } else {	    
            return express_with_bindings(binding_value(binding), frame);
        }
    } else if (is_pair(value)) {
        return make_pair_expression(express_with_bindings(head(value), frame), 
                                    express_with_bindings(tail(value), frame));
    } else { // value is a literal
        return make_literal(value);
    }
}
