function express(value, frame) {
    if (is_$_name(value)) {
        const binding = binding_in_frame(value, frame);
        if (is_undefined(binding)) {
            return value;
        } else {	    
            return express(binding_value(binding), frame);
        }
    } else if (is_pair(value)) {
        return express_pair(express(head(value), frame), 
                            express(tail(value), frame));
    } else { // value is a literal
        return express_literal(value);
    }
}
