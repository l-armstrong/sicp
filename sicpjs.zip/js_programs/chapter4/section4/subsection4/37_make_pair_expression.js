function make_pair_expression(head_expr, tail_expr) {
    return make_application(make_name("pair"),
                            list(head_expr, tail_expr));
}
