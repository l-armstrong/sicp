// functions from SICP JS 4.4.4
