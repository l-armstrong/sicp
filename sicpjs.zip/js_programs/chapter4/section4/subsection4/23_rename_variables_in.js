function make_new_variable(variable, rule_application_id) {
    return make_name(symbol_of_name(variable) + "_" +
                     stringify(rule_application_id));
}
let rule_counter = 0;

function new_rule_application_id() {
    rule_counter = rule_counter + 1;
    return rule_counter;
}
function is_tagged_list(component, the_tag) {
    return is_pair(component) && head(component) === the_tag;
}
function is_name(component) {
    return is_tagged_list(component, "name");
}
function rename_variables_in(rule) {
    const rule_application_id = new_rule_application_id();
    function tree_walk(exp) {
        return is_variable(exp) 
               ? make_new_variable(exp, rule_application_id)
               : is_pair(exp)
               ? pair(tree_walk(head(exp)),
                      tree_walk(tail(exp)))
               : exp;
    }
    return tree_walk(rule);
}

parse_query_verbose('assert(                           \
rule(append_to_form(null, y, y)))                ', "verbose");
parse_query_verbose('assert(                           \
rule(append_to_form(pair(u, v), y, pair(u, z)),  \
     append_to_form(v, y, z)))                   ', "verbose");
	  
first_answer('append_to_form(x, y, list("a", "b", "c", "d"))');
// parse_query_verbose('append_to_form(x, y, list("a", "b", "c", "d"))', "");
