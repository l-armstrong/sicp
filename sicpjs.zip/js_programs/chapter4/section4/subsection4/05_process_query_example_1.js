parse_and_process_query('assert(son("Adam", "Cain"))');
parse_and_process_query('son("Adam", x)');
