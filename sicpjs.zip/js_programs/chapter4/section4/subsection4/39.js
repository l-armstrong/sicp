parse_query('job($x, pair("computer", $type))');
