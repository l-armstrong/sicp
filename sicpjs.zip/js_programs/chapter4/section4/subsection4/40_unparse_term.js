function unparse_term(arg) {
    return is_var(arg)
           ? unparse_variable(arg)
           : is_operator_combination(arg)
           ? "(" + unparse_term(operator_combination_first_operand(arg)) +
             " " + operator_combination_operator_symbol(arg) +
             " " + unparse_term(operator_combination_second_operand(arg)) +
             ")"
           : is_literal(arg)
           ? stringify(literal_value(arg))
           : is_list(arg) &&
	     // exclude pairs whose tail is a pattern variable 
	     (is_null(arg) || is_null(tail(arg)) || head(tail(arg)) !== "?")
           ? unparse("list", arg, unparse_term)
           : is_pair(arg) 
           ? unparse("pair", list(head(arg), tail(arg)), unparse_term)
           : error(arg, "unknown term -- unparse_term");
}    
function is_list(xs) {    
    return is_null(xs) || is_list(tail(xs));
}
