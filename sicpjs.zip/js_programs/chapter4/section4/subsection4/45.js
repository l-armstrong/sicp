job($x, list("computer", "wizard"))
