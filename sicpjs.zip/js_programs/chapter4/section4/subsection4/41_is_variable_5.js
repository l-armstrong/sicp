function variable_to_name(variable) {
    const identifier = identifier_of_variable(variable);
    return is_pair(identifier)
           ? make_name(tail(identifier) + "_" + stringify(head(identifier)))
           : make_name(identifier);
}
