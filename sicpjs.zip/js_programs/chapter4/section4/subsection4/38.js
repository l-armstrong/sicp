'job(list("Bitdiddle", "Ben"), list("computer", "wizard"))'
