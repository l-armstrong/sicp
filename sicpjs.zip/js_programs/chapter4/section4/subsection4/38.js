function make_literal_expression(value) {
    return make_literal(value);
}
function make_pair_expression(head_expr, tail_expr) {
    return make_application(make_name("pair"),
                            list(head_expr, tail_expr));
}
