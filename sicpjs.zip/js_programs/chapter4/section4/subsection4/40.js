const my_pair = head(tail(tail(parse_query('job($x, pair("computer", $type))'))));
