const is_variable = is_name;
const symbol_of_variable = symbol_of_name;
