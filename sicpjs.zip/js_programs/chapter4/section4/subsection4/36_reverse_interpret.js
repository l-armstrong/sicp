function reverse_interpret(datum) {
    return is_variable(datum)
           ? datum
           : is_pair(datum)
           ? make_application(make_name("pair"),
                              list(reverse_interpret(head(datum)),
                                   reverse_interpret(tail(datum))))
           : // datum is a primitive value
             make_literal(datum);
}
