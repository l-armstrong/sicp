// operation_table, put and get
// from chapter 3 (section 3.3.3)
function assoc(key, records) {
    return is_null(records)
           ? undefined
           : equal(key, head(head(records)))
           ? head(records)
           : assoc(key, tail(records));
}
function make_table() {
    const local_table = list("*table*");
    function lookup(key_1, key_2) {
        const subtable = assoc(key_1, tail(local_table));
        if (is_undefined(subtable)) {
            return undefined;
        } else {
            const record = assoc(key_2, tail(subtable));
            return is_undefined(record)
                   ? undefined
                   : tail(record);
        }
    }
    function insert(key_1, key_2, value) {
        const subtable = assoc(key_1, tail(local_table));
        if (is_undefined(subtable)) {
            set_tail(local_table,
                     pair(list(key_1, pair(key_2, value)),
                          tail(local_table)));
        } else {
            const record = assoc(key_2, tail(subtable));
            if (is_undefined(record)) {
      	        set_tail(subtable,
	                       pair(pair(key_2, value),
                              tail(subtable)));
	    } else {
                set_tail(record, value);
            }
        }
    }
    function dispatch(m) {
        return m === "lookup"
               ? lookup
               : m === "insert"
               ? insert
               : error(m, "unknown operation -- table");
    }
    return dispatch;
}
const operation_table = make_table();
const get = operation_table("lookup");
const put = operation_table("insert");
function make_binding(variable, value) {
    return pair(variable, value);
}
function binding_variable(binding) {
    return head(binding);
}
function binding_value(binding) {
    return tail(binding);
}
function binding_in_frame(variable, frame) {
    return assoc(variable, frame);
}
function extend(variable, value, frame) {
    return pair(make_binding(variable, value), frame);
}
function is_tagged_list(component, the_tag) {
    return is_pair(component) && head(component) === the_tag;
}
function is_name(component) {
    return is_tagged_list(component, "name");
}
function instantiate_datum(datum, frame) {
    if (is_variable(datum)) {
        const binding = binding_in_frame(datum, frame);
        return is_undefined(binding)
               ? datum
               : instantiate_datum(binding_value(binding), frame);
    } else if (is_pair(datum)) {
        return pair(instantiate_datum(head(datum), frame), 
                    instantiate_datum(tail(datum), frame));
    } else { // datum is a primitive value
        return datum;
    }
}
function reify_datum(datum) {
    return is_variable(datum)
           ? datum
           : is_pair(datum)
           ? make_application(make_name("pair"),
                              list(reify_datum(head(datum)),
                                   reify_datum(tail(datum))))
           : // datum is a primitive value
             make_literal(datum);
}
function instantiate_expression(expression, frame) {
    function copy(expression) {
        return is_variable(expression)
               ? reify_datum(instantiate_datum(expression, frame))
               : is_pair(expression)
               ? pair(copy(head(expression)), 
                      copy(tail(expression)))
               : expression;
    }
    return copy(expression);
}

parse_query_verbose('assert(                           \
rule(append_to_form(null, y, y)))                ', "verbose");
parse_query_verbose('assert(                           \
rule(append_to_form(pair(u, v), y, pair(u, z)),  \
     append_to_form(v, y, z)))                   ', "verbose");
	  
first_answer('append_to_form(x, y, list("a", "b", "c", "d"))');
// parse_query_verbose('append_to_form(x, y, list("a", "b", "c", "d"))', "");
