function reverse_interpret(term) {
    return is_variable(term)
           ? term
           : is_pair(term)
           ? make_application(make_name("pair"),
                              list(reverse_interpret(head(term)),
                                   reverse_interpret(tail(term))))
           : // term is a primitive value
             make_literal(term);
}
