reverse(list(1, 2, 3));
