literal_value(parse("null;"));
