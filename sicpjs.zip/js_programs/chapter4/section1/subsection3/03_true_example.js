is_truthy(false); // should return false because only true is truthy
