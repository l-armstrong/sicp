function is_integer(x) {
    return x === math_floor(x);
}
a_pythagorean_triple_between(5, 15);
