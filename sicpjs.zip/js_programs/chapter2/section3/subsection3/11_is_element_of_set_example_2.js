is_element_of_set(15, list(10, 15, 20));
