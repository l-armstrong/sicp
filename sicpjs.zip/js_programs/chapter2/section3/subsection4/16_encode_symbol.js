// encode_symbol function to be written by students
