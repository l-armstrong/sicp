function make_sum(a1, a2) {
    return list("+", a1, a2);
}
is_sum(make_sum("x", 3));
