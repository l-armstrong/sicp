function make_sum(a1, a2) {
    return list("+", a1, a2);
}
augend(make_sum("x", 3));
