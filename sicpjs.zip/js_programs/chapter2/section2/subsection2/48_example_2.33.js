length(subsets(list(1, 2)));
