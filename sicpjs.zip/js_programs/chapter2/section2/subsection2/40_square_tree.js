// square_tree to be written by student
