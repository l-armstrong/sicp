const alyssas_co_num = make_from_mag_ang_polar(
                           3.0, 0.7);

imag_part_polar(contents(alyssas_co_num));
