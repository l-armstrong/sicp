const s = make_monitored(math_sqrt);
s(100);
s("how_many_calls");
s(5);
s("how_many_calls");
