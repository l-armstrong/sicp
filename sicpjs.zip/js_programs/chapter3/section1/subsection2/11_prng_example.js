rand("generate");
rand("generate");
rand("generate");

// This generates 919, 47, 127

rand("reset")(2);

// State is reset to 2 again

rand("generate");
rand("generate");
rand("generate");

// Because initial state is the same, 919, 47, 127 is generated
