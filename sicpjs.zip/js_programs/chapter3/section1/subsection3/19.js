function make_account(balance) {
    function withdraw(amount) {
        if (balance >= amount) {
            balance = balance - amount;
            return balance;
        } else {
            return "Insufficient funds";
        }
    }
    function deposit(amount) {
        balance = balance + amount;
        return balance;
    }
    function dispatch(m) {
        return m === "withdraw"
               ? withdraw
               : m === "deposit"
               ? deposit
               : error(m, "unknown request -- make_account");
    }
    return dispatch;
}
const peter_acc = make_account(100);
const paul_acc = peter_acc;
peter_acc("withdraw")(10);
peter_acc("withdraw")(20);
paul_acc("withdraw")(50);

// expected: 20
