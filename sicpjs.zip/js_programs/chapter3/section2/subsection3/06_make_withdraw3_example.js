const W1 = make_withdraw(100);
W1(80);
