const x = 2;
{
    let x = 4;
    {
        const x = 6;
        x = x + 1;
    }
    x = x + 1;
}
x = x + 1;

const my_block = parse("{ 1; true; 45; }");
display(is_block(my_block));
display(block_body(my_block));
