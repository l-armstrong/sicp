const square = x => x * x;

square(14);

// expected: 196
