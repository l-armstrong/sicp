function square(x) {
    return x * x;
}

square(14);

// expected: 196
