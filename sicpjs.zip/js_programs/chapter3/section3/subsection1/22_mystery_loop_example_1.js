const v = list("a", "b", "c");
