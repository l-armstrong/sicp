const display = x => x;
