stream_ref(dirichlet_stream, 42);
