const from_20 = integers_starting_from(20);
stream_ref(from_20, 50);
