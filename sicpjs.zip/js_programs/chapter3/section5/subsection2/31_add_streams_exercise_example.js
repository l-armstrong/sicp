eval_stream(s, 50);
