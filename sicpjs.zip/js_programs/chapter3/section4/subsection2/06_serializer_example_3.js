// chapter=3 variant=concurrent 
let x = 10;

concurrent_execute(ignore => { x = x * x; }, 
                   ignore => { x = x * x * x; } );

// expected: 'all threads terminated'
