// chapter=3 variant=concurrent 
let x = 10;

concurrent_execute(ignore => { x = x * x; },
                   ignore => { x = x + 1; } );

// expected: 'all threads terminated'
