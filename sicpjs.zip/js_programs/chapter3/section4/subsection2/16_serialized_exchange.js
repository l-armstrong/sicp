// chapter=3 variant=concurrent 
function make_mutex() {
    const cell = list(false);
    function the_mutex(m) {
        return m === "acquire"
               ? ( test_and_set(cell)
                   ? the_mutex("acquire") // retry
                   : true )
               : m === "release"
                 ? clear(cell)
                 : error(m, "Unknown request -- mutex");
    }
    return the_mutex;
}
function clear(cell) {
    set_head(cell, false);
}
function make_serializer() {
    const mutex = make_mutex();
    return p => 
             arg => {
                 mutex("acquire");
                 const val = p(arg);
                 mutex("release");
                 return val;
             };
}
function make_account_and_serializer(balance) {
    function withdraw(amount) {
        if (balance > amount) {
            balance = balance - amount;
        } else {
            "Insufficient funds";
        }
    }
    function deposit(amount) {
        balance = balance + amount;
        return balance;
    }
    const balance_serializer = make_serializer();
    return m => m === "withdraw"
                ? withdraw
                : m === "deposit"
                ? deposit
                : m === "balance"
                ? balance
                : m === "serializer"
                ? balance_serializer
                : error(m, 
                   "Unknown request -- make_account");
}
function make_account(balance) {
    function withdraw(amount) {
        if (balance > amount) {
            balance = balance - amount;
            return balance;
        } else {
            return "Insufficient funds";
        }
    }
    function deposit(amount) {
        balance = balance + amount;
        return balance;
    }
    const protect = make_serializer();
    function dispatch(m) {
        return m === "withdraw" 
            ? protect(withdraw)
            : m === "deposit"
              ? protect(deposit)
              : m === "balance"
                ? balance
                : error(m,
                   "Unknown request -- make_account");
    }
    return dispatch;
}
function exchange(accounts) {
    const account1 = head(accounts);	
    const account2 = tail(accounts);	
    const difference = account1("balance") - account2("balance");
    account1("withdraw")(difference);
    account2("deposit")(difference);
}
function serialized_exchange(accounts) {
    const account1 = head(accounts);	
    const account2 = tail(accounts);	
    const serializer1 = account1("serializer");
    const serializer2 = account2("serializer");
    serializer1(serializer2(exchange))(accounts);
}

const a1 = make_account_and_serializer(100);
const a2 = make_account_and_serializer(200);
const a3 = make_account_and_serializer(300);

concurrent_execute(_ => { display(a1("balance"), "Peter balance a1 before");
                          display(a2("balance"), "Peter balance a2 before");
                          serialized_exchange(pair(a1, a2));
                          display(a1("balance"), "Peter balance a1 after");
                          display(a2("balance"), "Peter balance a2 after");
                        },
                   _ => { display(a1("balance"), "Paul balance a1 before");
                          display(a3("balance"), "Paul balance a3 before");
                          serialized_exchange(pair(a1, a3));
                          display(a1("balance"), "Paul balance a1 after");
                          display(a3("balance"), "Paul balance a3 after");
                        }
                  );
