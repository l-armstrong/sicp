withdraw(25); // output: 75
